(function() {
  var style = getComputedStyle(document.documentElement);
  var accent = style.getPropertyValue('--accent').trim();
  var accent2 = style.getPropertyValue('--accent2').trim();
  var accent3 = style.getPropertyValue('--accent3').trim();
  var ink = style.getPropertyValue('--ink').trim();
  var muted = style.getPropertyValue('--muted').trim();
  var rule = style.getPropertyValue('--rule').trim();
  var bg2 = style.getPropertyValue('--bg2').trim();
  var green = style.getPropertyValue('--green').trim();
  var yellow = style.getPropertyValue('--yellow').trim();
  var red = style.getPropertyValue('--red').trim();

  // --- Chart: Rank Pie ---
  var chart1 = echarts.init(document.getElementById('chart-rank-pie'), null, { renderer: 'svg' });
  chart1.setOption({
    animation: false,
    tooltip: { trigger: 'item', appendToBody: true, backgroundColor: '#1E293B', borderColor: rule, textStyle: { color: ink, fontSize: 12 } },
    legend: { bottom: 10, textStyle: { color: muted, fontSize: 11 } },
    series: [{
      type: 'pie',
      radius: ['40%', '70%'],
      center: ['50%', '45%'],
      avoidLabelOverlap: false,
      itemStyle: { borderRadius: 6, borderColor: '#0F172A', borderWidth: 2 },
      label: { color: ink, fontSize: 11, formatter: '{b}\n{d}%' },
      data: [
        { value: 8, name: '技术部', itemStyle: { color: accent } },
        { value: 3, name: '管理层', itemStyle: { color: accent2 } },
        { value: 2, name: '产品部', itemStyle: { color: accent3 } },
        { value: 2, name: '设计部', itemStyle: { color: green } },
        { value: 2, name: '市场部', itemStyle: { color: yellow } },
        { value: 1, name: '法务', itemStyle: { color: red } }
      ]
    }]
  });
  window.addEventListener('resize', function() { chart1.resize(); });

  // --- Chart: Department Bar ---
  var chart2 = echarts.init(document.getElementById('chart-dept-bar'), null, { renderer: 'svg' });
  chart2.setOption({
    animation: false,
    tooltip: { trigger: 'axis', appendToBody: true, backgroundColor: '#1E293B', borderColor: rule, textStyle: { color: ink, fontSize: 12 } },
    grid: { left: 60, right: 20, top: 30, bottom: 40 },
    xAxis: { type: 'category', data: ['技术部', '产品部', '设计部', '市场部', '管理层', '法务', '客户成功'], axisLabel: { color: muted, fontSize: 10 }, axisLine: { lineStyle: { color: rule } } },
    yAxis: { type: 'value', axisLabel: { color: muted, fontSize: 10 }, splitLine: { lineStyle: { color: rule, type: 'dashed' } }, axisLine: { show: false } },
    series: [{
      type: 'bar',
      data: [
        { value: 8, itemStyle: { color: accent } },
        { value: 2, itemStyle: { color: accent2 } },
        { value: 2, itemStyle: { color: accent3 } },
        { value: 2, itemStyle: { color: green } },
        { value: 3, itemStyle: { color: yellow } },
        { value: 1, itemStyle: { color: red } },
        { value: 1, itemStyle: { color: muted } }
      ],
      barWidth: '50%',
      label: { show: true, position: 'top', color: ink, fontSize: 11, fontWeight: 'bold' }
    }]
  });
  window.addEventListener('resize', function() { chart2.resize(); });

  // --- Chart: Commit Line ---
  var chart3 = echarts.init(document.getElementById('chart-commit-line'), null, { renderer: 'svg' });
  chart3.setOption({
    animation: false,
    tooltip: { trigger: 'axis', appendToBody: true, backgroundColor: '#1E293B', borderColor: rule, textStyle: { color: ink, fontSize: 12 } },
    grid: { left: 60, right: 20, top: 30, bottom: 40 },
    xAxis: { type: 'category', data: ['6月', '7月', '8月', '9月'], axisLabel: { color: muted, fontSize: 11 }, axisLine: { lineStyle: { color: rule } } },
    yAxis: { type: 'value', name: '提交数', nameTextStyle: { color: muted, fontSize: 10 }, axisLabel: { color: muted, fontSize: 10 }, splitLine: { lineStyle: { color: rule, type: 'dashed' } }, axisLine: { show: false } },
    series: [{
      type: 'line',
      data: [180, 210, 195, 245],
      smooth: true,
      symbol: 'circle',
      symbolSize: 8,
      lineStyle: { color: accent, width: 3 },
      itemStyle: { color: accent, borderColor: '#0F172A', borderWidth: 2 },
      areaStyle: { color: { type: 'linear', x: 0, y: 0, x2: 0, y2: 1, colorStops: [{ offset: 0, color: accent + '40' }, { offset: 1, color: accent + '05' }] } },
      label: { show: true, position: 'top', color: ink, fontSize: 11, fontWeight: 'bold' }
    }]
  });
  window.addEventListener('resize', function() { chart3.resize(); });

  // --- Chart: Delivery Bar ---
  var chart4 = echarts.init(document.getElementById('chart-delivery-bar'), null, { renderer: 'svg' });
  chart4.setOption({
    animation: false,
    tooltip: { trigger: 'axis', appendToBody: true, backgroundColor: '#1E293B', borderColor: rule, textStyle: { color: ink, fontSize: 12 } },
    legend: { data: ['目标完成率', '实际完成率'], bottom: 0, textStyle: { color: muted, fontSize: 10 } },
    grid: { left: 50, right: 20, top: 20, bottom: 40 },
    xAxis: { type: 'category', data: ['用户认证', 'RAG 引擎', '支付系统', '多设备管理', '安全测试'], axisLabel: { color: muted, fontSize: 10, rotate: 15 }, axisLine: { lineStyle: { color: rule } } },
    yAxis: { type: 'value', max: 110, axisLabel: { color: muted, fontSize: 10, formatter: '{value}%' }, splitLine: { lineStyle: { color: rule, type: 'dashed' } }, axisLine: { show: false } },
    series: [
      {
        name: '目标完成率',
        type: 'bar',
        barGap: '20%',
        data: [100, 100, 100, 100, 100],
        itemStyle: { color: rule, borderRadius: [3, 3, 0, 0] },
        barWidth: '28%'
      },
      {
        name: '实际完成率',
        type: 'bar',
        data: [
          { value: 100, itemStyle: { color: green, borderRadius: [3, 3, 0, 0] } },
          { value: 100, itemStyle: { color: green, borderRadius: [3, 3, 0, 0] } },
          { value: 100, itemStyle: { color: green, borderRadius: [3, 3, 0, 0] } },
          { value: 0, itemStyle: { color: red, borderRadius: [3, 3, 0, 0] } },
          { value: 0, itemStyle: { color: red, borderRadius: [3, 3, 0, 0] } }
        ],
        barWidth: '28%',
        label: { show: true, position: 'top', color: ink, fontSize: 10, fontWeight: 'bold', formatter: function(p) { return p.value === 0 ? '未完成' : p.value + '%'; } }
      }
    ]
  });
  window.addEventListener('resize', function() { chart4.resize(); });
})();
